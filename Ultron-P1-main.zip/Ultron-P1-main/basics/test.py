from time import sleep
import pyautogui
from time import sleep
sleep(10)
ans = pyautogui.position()

print(ans)
